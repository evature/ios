//
//  ViewController.h
//  SpeechRecognizer
//
//  Created by hayashi on 1/31/13.
//  Copyright (c) 2013 hayashi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
