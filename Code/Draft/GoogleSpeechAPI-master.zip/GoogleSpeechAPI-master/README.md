GoogleSpeechAPI
===============

Example code for using Google's speech recogniton private APIs on iOS devices.  
This project includes [libFLAC](http://flac.sourceforge.net/) source files.
